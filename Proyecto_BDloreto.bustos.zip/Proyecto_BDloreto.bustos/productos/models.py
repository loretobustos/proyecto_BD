from django.db import models

# Modelo que representa la entidad Producto en la base de datos SQLite
class Producto(models.Model):
    # Nombre descriptivo del producto
    nombre = models.CharField(max_length=100)
    
    # Marca del fabricante
    marca = models.CharField(max_length=100)
    
    # Precio expresado en valor entero
    precio = models.IntegerField()
    
    # Departamento o categoría (Tecnología, Hogar, Deportes)
    categoria = models.CharField(max_length=50)
    
    # Nombre del archivo de imagen ubicado en static/img/
    imagen = models.CharField(max_length=100, default='notebook.png')

    def __str__(self):
        return f"{self.nombre} ({self.categoria})"