from django.shortcuts import render, redirect, get_object_or_404
from .models import Producto

# Muestra la página principal de inicio
# Parámetros: request (HttpRequest)
# Retorno: Renderizado de la plantilla index.html
def mostrarIndex(request):
    return render(request, 'index.html')

# Muestra el formulario para registrar un nuevo producto
# Parámetros: request (HttpRequest)
# Retorno: Renderizado de form_registrar.html
def mostrarFormRegistrar(request):
    return render(request, 'form_registrar.html')

# Alias por compatibilidad
def form_registrar(request):
    return mostrarFormRegistrar(request)

# Procesa los datos enviados desde el formulario y guarda el producto en la BD
# Parámetros: request (HttpRequest con datos POST)
# Retorno: Redirección hacia la vista del listado
def insertarProducto(request):
    if request.method == 'POST':
        nombre = request.POST.get('nombre')
        precio = request.POST.get('precio')
        categoria = request.POST.get('categoria')
        
        imagen = f"{nombre.strip().lower()}.png" if nombre else "notebook.png"

        Producto.objects.create(
            nombre=nombre,
            precio=precio,
            categoria=categoria,
            imagen=imagen
        )
        return redirect('/listado')
    return redirect('/form_registrar')

# Obtiene la lista completa de productos desde la base de datos
# Parámetros: request (HttpRequest)
# Retorno: Renderizado de listado.html con el contexto de productos
def mostrarListado(request):
    productos = Producto.objects.all()
    return render(request, 'listado.html', {'productos': productos})

# Muestra el formulario de actualización con los datos del producto
# Parámetros: request (HttpRequest), id (identificador del producto)
# Retorno: Renderizado de form_actualizar.html
def mostrarFormActualizar(request, id):
    producto = get_object_or_404(Producto, id=id)
    return render(request, 'form_actualizar.html', {'producto': producto})

# Alias por compatibilidad
def form_actualizar(request, id):
    return mostrarFormActualizar(request, id)

# Actualiza los cambios de un producto existente en la base de datos
# Parámetros: request (HttpRequest), id (identificador del producto)
# Retorno: Redirección a la vista de listado
def actualizarProducto(request, id):
    if request.method == 'POST':
        producto = get_object_or_404(Producto, id=id)
        producto.nombre = request.POST.get('nombre')
        producto.precio = request.POST.get('precio')
        producto.categoria = request.POST.get('categoria')
        producto.save()
        return redirect('/listado')
    return redirect('/listado')

# Elimina un producto seleccionado de la base de datos
# Parámetros: request (HttpRequest), id (identificador del producto)
# Retorno: Redirección a la vista de listado
def eliminarProducto(request, id):
    producto = get_object_or_404(Producto, id=id)
    producto.delete()
    return redirect('/listado')